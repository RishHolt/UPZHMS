<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;

class HousingController extends Controller
{
    /**
     * Display the housing registry dashboard
     */
    public function index()
    {
        return Inertia::render('module-3/HousingDashboard');
    }

    /**
     * Display the housing applications
     */
    public function applications()
    {
        return Inertia::render('module-3/HousingApplication');
    }
}

