<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create IT Admin user
        User::create([
            'firstName' => 'System',
            'lastName' => 'Administrator',
            'email' => 'admin@upzhms.com',
            'password' => Hash::make('admin123'),
            'contactNumber' => '+63 912 345 6789',
            'role' => 'IT_ADMIN',
            'status' => 'ACTIVE',
            'email_verified_at' => now(),
        ]);

        // Create sample Zoning Officer
        User::create([
            'firstName' => 'John',
            'lastName' => 'Doe',
            'email' => 'zoning@upzhms.com',
            'password' => Hash::make('password123'),
            'contactNumber' => '+63 912 345 6790',
            'role' => 'ZONING_OFFICER',
            'status' => 'ACTIVE',
            'email_verified_at' => now(),
        ]);

        // Create sample Building Officer
        User::create([
            'firstName' => 'Jane',
            'lastName' => 'Smith',
            'email' => 'building@upzhms.com',
            'password' => Hash::make('password123'),
            'contactNumber' => '+63 912 345 6791',
            'role' => 'BUILDING_OFFICER',
            'status' => 'ACTIVE',
            'email_verified_at' => now(),
        ]);
    }
}
